//
//  File.swift
//  CoreData_Sample
//
//  Created by ajay on 18/05/24.
//

import Foundation

struct StudentModel: Decodable {
    
    var id: Int?
    var name: String?
    var marks: MarksModel?
    
    func getData(count: Int) -> [StudentModel]{
        
        var arr = [StudentModel]()
        for i in 1..<count {
            arr.append(StudentModel(id: i,name: "A - \(i)", marks: MarksModel(tel: i+100, eng: i+100, maths: i+100 )))
        }
        
        return arr
    }
}

struct MarksModel: Decodable {
    
    var tel: Int?
    var eng: Int?
    var maths: Int?
}
